

$('.owl-carousel').owlCarousel({
    loop:true,
    nav:false,
    autoplay:true,
    autoplayTimeout:4000,
    items:1,
    animateIn : "fadeInRight"

});


var filterizd = $('.filter-container').filterizr({
  animationDuration: .5,

});



